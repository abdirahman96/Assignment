package AP;



import java.awt.image.BufferedImage;

import java.io.File;

import java.io.FileInputStream;

import java.io.FileNotFoundException;

import java.io.IOException;
import java.util.ArrayList;


public class MNIST {

	ArrayList<int[]> img_L;
    ArrayList<int[]> Labelimg_L;
    
    public MNIST (){
    	img_L = new  ArrayList<int[]>();
    	Labelimg_L = new ArrayList<int[]>();
    }
    
    public ArrayList<int[]> getimg() {
    	return img_L;
    }
    
    public ArrayList<int[]> getLabel() {
    	return Labelimg_L;
    }

 public BufferedImage read() throws IOException {

      String train_label_filename = ("MNIST/train-labels-idx1-ubyte");
      String train_image_filename = ("MNIST/train-images-idx3-ubyte");
      
     
      FileInputStream in_stream_labels = null;
      FileInputStream in_stream_image = null;
      
   try {
   in_stream_labels = new FileInputStream(new File(train_label_filename));
   in_stream_image = new FileInputStream(new File(train_image_filename));

  int labels_start_code = (in_stream_labels.read() << 24) |
		  (in_stream_labels.read() << 16) |
          (in_stream_labels.read() << 8) |
          (in_stream_labels.read());

              System.out.println("label start code: " + labels_start_code);

                                        

   int image_start_code = (in_stream_image.read() << 24) |

        (in_stream_image.read() << 16) |

          (in_stream_image.read() << 8) |

           (in_stream_image.read());

           System.out.println("image start code: " + image_start_code);

                                        

  int number_of_labels = (in_stream_labels.read() << 24) |
		  (in_stream_labels.read() << 16)  |
		  (in_stream_labels.read() << 8) |
		  (in_stream_labels.read());

                                                                    

                                                                   
                                        

    int number_of_image = (in_stream_image.read() << 24) |

        (in_stream_image.read() << 16) |

         (in_stream_image.read() << 8) |
         (in_stream_image.read()); 

                                                                    

                                        
    System.out.println("number of labels and image: " + number_of_labels + " and " + number_of_image);

                                        
    	int image_height = (in_stream_image.read() << 24) |

    					   (in_stream_image.read() << 16) |

                           (in_stream_image.read() << 8) |

                    	   (in_stream_image.read());

                                        

     int image_width = (in_stream_image.read() << 24) |

                       (in_stream_image.read() << 16) |

                       (in_stream_image.read() << 8) |

                       (in_stream_image.read());

                                      
    System.out.println("Image size: " + image_width + " x " + image_height);

         int image_size = image_width + image_height;

                                        
         int[] label_list = new int[number_of_labels];

          int[] image_data = new int[image_width * image_height];

                                        
          for(int record = 0; record < number_of_image; record++) {

       BufferedImage currentImg = new BufferedImage(image_width, image_height, BufferedImage.TYPE_INT_ARGB);

                                                      

                                                       int label = in_stream_labels.read();

                                                       label_list[record] = label;

                                                       System.out.println(label);

                                                      

                                                       

                                                      

                                                       for(int pixel = 0; pixel < image_size; pixel++) {

                                                                   

                                                                    int gray_value = in_stream_image.read();

                                                                    int rgb_value = 0xFF000000 | (gray_value << 16) |

                                                                                                (gray_value << 8) |

                                                                                                (gray_value);

                                                                   

                                                                    image_data[pixel] = rgb_value;

     }

      currentImg.setRGB(0, 0, image_width, image_height, image_data,  0, image_width);

                                                      

                                         }

                                                                   
// add the last bit over here 
          img_L.add(image_data);
          
          
                           }catch(FileNotFoundException e) {
                        	

                                         System.out.println("Application Cannot find file " + e.toString());

                           }
return null;

              }

}
