package AP;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;

import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JPanel;
import net.miginfocom.swing.MigLayout;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JTextField;
 
public class GUI {
	
 
  JButton clearBtn;
  DrawArea drawArea;
  ActionListener actionListener = new ActionListener() {
 
  public void actionPerformed(ActionEvent e) {
      if (e.getSource() == clearBtn) {
        drawArea.clear();
      }
    }
  };
  private JTextField txtHandWrittenRecognition;
  private JTextField txtHandwrittenRecognition;
 
  public void main() {
    new GUI().show();
  }
 
  /**
   * @wbp.parser.entryPoint
   */
  public void show() {
    // create main frame
    JFrame frame = new JFrame("Swing Paint");
    frame.getContentPane().setBackground(Color.ORANGE);
    Container content = frame.getContentPane();
    
       // create controls to apply colors and call clear feature
       JPanel controls = new JPanel();
       controls.setBounds(0, 0, 570, 34);
       
          clearBtn = new JButton("Clear");
          clearBtn.addActionListener(actionListener);
    // create draw area
    drawArea = new DrawArea();
    drawArea.setBounds(10, 61, 220, 195);
       
       JPanel panel = new JPanel();
       panel.setBounds(10, 274, 220, 161);
       panel.setBackground(Color.WHITE);
       frame.getContentPane().setLayout(null);
       
       JButton btnUpload = new JButton("Upload");
       btnUpload.addActionListener(new ActionListener() {
       	public void actionPerformed(ActionEvent e) {
       		UpLoadImage UI = new UpLoadImage();
       		UI.main(null);
       	}
       });
       GroupLayout gl_controls = new GroupLayout(controls);
       gl_controls.setHorizontalGroup(
       	gl_controls.createParallelGroup(Alignment.LEADING)
       		.addGroup(gl_controls.createSequentialGroup()
       			.addGap(18)
       			.addComponent(clearBtn, GroupLayout.PREFERRED_SIZE, 106, GroupLayout.PREFERRED_SIZE)
       			.addGap(78)
       			.addComponent(btnUpload)
       			.addContainerGap(279, Short.MAX_VALUE))
       );
       gl_controls.setVerticalGroup(
       	gl_controls.createParallelGroup(Alignment.LEADING)
       		.addGroup(gl_controls.createSequentialGroup()
       			.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
       			.addGroup(gl_controls.createParallelGroup(Alignment.BASELINE)
       				.addComponent(clearBtn)
       				.addComponent(btnUpload)))
       );
       controls.setLayout(gl_controls);
       frame.getContentPane().add(controls);
       frame.getContentPane().add(panel);
       frame.getContentPane().add(drawArea);
       
       txtHandWrittenRecognition = new JTextField();
       txtHandWrittenRecognition.setText("Hand Written Recognition");
       txtHandWrittenRecognition.setBounds(316, 124, 99, -28);
       frame.getContentPane().add(txtHandWrittenRecognition);
       txtHandWrittenRecognition.setColumns(10);
       
       txtHandwrittenRecognition = new JTextField();
       txtHandwrittenRecognition.setText("HandWritten Recognition");
       txtHandwrittenRecognition.setBounds(273, 61, 148, 35);
       frame.getContentPane().add(txtHandwrittenRecognition);
       txtHandwrittenRecognition.setColumns(10);
 
    frame.setSize(600, 600);
    // can close frame
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    // show the swing paint result
    frame.setVisible(true);
 
 
  }
}




class DrawArea extends JComponent {
	 
	  // Image in which we're going to draw
	  private Image image;
	  // Graphics2D object ==> used to draw on
	  private Graphics2D g2;
	  // Mouse coordinates
	  private int currentX, currentY, oldX, oldY;
	 
	  public DrawArea() {
	    setDoubleBuffered(false);
	    addMouseListener(new MouseAdapter() {
	      public void mousePressed(MouseEvent e) {
	        // save coord x,y when mouse is pressed
	        oldX = e.getX();
	        oldY = e.getY();
	      }
	    });
	 
	    addMouseMotionListener(new MouseMotionAdapter() {
	      public void mouseDragged(MouseEvent e) {
	        // coord x,y when drag mouse
	        currentX = e.getX();
	        currentY = e.getY();
	 
	        if (g2 != null) {
	          // draw line if g2 context not null
	          g2.drawLine(oldX, oldY, currentX, currentY);
	          // refresh draw area to repaint
	          repaint();
	          // store current coords x,y as olds x,y
	          oldX = currentX;
	          oldY = currentY;
	        }
	      }
	    });
	  }
	 
	  protected void paintComponent(Graphics g) {
	    if (image == null) {
	      // image to draw null ==> we create
	      image = createImage(getSize().width, getSize().height);
	      g2 = (Graphics2D) image.getGraphics();
	      // enable antialiasing
	      g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
	      // clear draw area
	      clear();
	    }
	 
	    g.drawImage(image, 0, 0, null);
	  }
	 
	  // now we create exposed methods
	  public void clear() {
	    g2.setPaint(Color.white);
	    // draw white on entire draw area to clear
	    g2.fillRect(0, 0, getSize().width, getSize().height);
	    g2.setPaint(Color.black);
	    repaint();
	  }
	 
	  public void red() {
	    // apply red color on g2 context
	    g2.setPaint(Color.red);
	  }
	 
	  public void black() {
	    g2.setPaint(Color.black);
	  }
	 
	  public void magenta() {
	    g2.setPaint(Color.magenta);
	  }
	 
	  public void green() {
	    g2.setPaint(Color.green);
	  }
	 
	  public void blue() {
	    g2.setPaint(Color.blue);
	  }
	 
	}